﻿namespace test
{
    /*class main
    {
        public static void Main()
        {
            Form frm = new Form();
            frm.Paint += new PaintEventHandler(frm_Paint); //注册Paint事件处理程序
            frm.Click += new System.EventHandler(frm_Click);//注册Click事件处理程序
            Application.Run(frm);
        }
    }*/
}